import React from 'react'
import '../cssfolder/contact.css';

export default function Contact() {
  return (
    <div className='footer-contact'>
        <div>
        <p>
            Nipun Anand : +91 8899794874
        </p>
        </div>
    </div>
  )
}
